from fastapi import FastAPI
from Main import check_instagram_user

app = FastAPI()

@app.get("/check_user/{username}")
def read_user(username: str):
    result = check_instagram_user(username)
    return result
