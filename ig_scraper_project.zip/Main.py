import requests

def check_instagram_user(username):
    url = f"https://instagram-scraper-2023.p.rapidapi.com/ig/user/{username}"
    headers = {
        "X-RapidAPI-Key": "your_rapidapi_key_here",
        "X-RapidAPI-Host": "instagram-scraper-2023.p.rapidapi.com"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return {
            "username": data.get("username", "N/A"),
            "followers": data.get("followers_count", "N/A"),
            "is_verified": data.get("is_verified", "N/A")
        }
    else:
        return {"error": f"Failed to fetch data. Status code: {response.status_code}"}
