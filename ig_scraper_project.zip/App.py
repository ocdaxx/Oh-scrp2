from fastapi import FastAPI, HTTPException
from Main import check_instagram_subscription

app = FastAPI()

@app.get("/check_subscription/")
async def check_subscription(username: str):
    try:
        result = check_instagram_subscription(username)
        return {"status": "success", "message": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
